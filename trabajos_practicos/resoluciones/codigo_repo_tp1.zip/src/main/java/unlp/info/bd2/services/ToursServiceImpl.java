package unlp.info.bd2.services;

import unlp.info.bd2.model.*;
import unlp.info.bd2.repositories.ToursRepository;
import unlp.info.bd2.utils.ToursException;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public class ToursServiceImpl implements ToursService {

    private ToursRepository repository;

    public ToursServiceImpl(ToursRepository repository) {
        this.repository = repository;
    }

    @Override
    public User createUser(String username, String password, String fullName, String email, Date birthdate, String phoneNumber) throws ToursException {
        return null;
    }

    @Override
    public DriverUser createDriverUser(String username, String password, String fullName, String email, Date birthdate, String phoneNumber, String expedient) throws ToursException {
        return null;
    }

    @Override
    public TourGuideUser createTourGuideUser(String username, String password, String fullName, String email, Date birthdate, String phoneNumber, String education) throws ToursException {
        return null;
    }

    @Override
    public Optional<User> getUserById(Long id) throws ToursException {
        return Optional.empty();
    }

    @Override
    public Optional<User> getUserByUsername(String username) throws ToursException {
        return Optional.empty();
    }

    @Override
    public User updateUser(User user) throws ToursException {
        return null;
    }

    @Override
    public void deleteUser(User user) throws ToursException {}

    @Override
    public Stop createStop(String name, String description) throws ToursException {
        return null;
    }

    @Override
    public List<Stop> getStopByNameStart(String name) {
        return null;
    }

    @Override
    public Route createRoute(String name, float price, float totalKm, int maxNumberOfUsers, List<Stop> stops) throws ToursException {
        return null;
    }

    @Override
    public Optional<Route> getRouteById(Long id) {
        return Optional.empty();
    }

    @Override
    public List<Route> getRoutesBelowPrice(float price) {
        return null;
    }

    @Override
    public void assignDriverByUsername(String username, Long idRoute) throws ToursException {}

    @Override
    public void assignTourGuideByUsername(String username, Long idRoute) throws ToursException {}

    @Override
    public Supplier createSupplier(String businessName, String authorizationNumber) throws ToursException {
        return null;
    }

    @Override
    public Service addServiceToSupplier(String name, float price, String description, Supplier supplier) throws ToursException {
        return null;
    }

    @Override
    public Service updateServicePriceById(Long id, float newPrice) throws ToursException {
        return null;
    }

    @Override
    public Optional<Supplier> getSupplierById(Long id) {
        return Optional.empty();
    }

    @Override
    public Optional<Supplier> getSupplierByAuthorizationNumber(String authorizationNumber) {
        return Optional.empty();
    }

    @Override
    public Optional<Service> getServiceByNameAndSupplierId(String name, Long id) throws ToursException {
        return Optional.empty();
    }

    @Override
    public Purchase createPurchase(String code, Route route, User user) throws ToursException {
        return null;
    }

    @Override
    public Purchase createPurchase(String code, Date date, Route route, User user) throws ToursException {
        return null;
    }

    @Override
    public ItemService addItemToPurchase(Service service, int quantity, Purchase purchase) throws ToursException {
        return null;
    }

    @Override
    public Optional<Purchase> getPurchaseByCode(String code) {
        return Optional.empty();
    }

    @Override
    public void deletePurchase(Purchase purchase) throws ToursException {}

    @Override
    public Review addReviewToPurchase(int rating, String comment, Purchase purchase) throws ToursException {
        return null;
    }

    @Override
    public void deleteRoute(Route route) throws ToursException {}

    @Override
    public List<Purchase> getAllPurchasesOfUsername(String username) {
        return null;
    }

    @Override
    public List<User> getUserSpendingMoreThan(float mount) {
        return null;
    }

    @Override
    public List<Supplier> getTopNSuppliersInPurchases(int n) {
        return null;
    }

    @Override
    public long getCountOfPurchasesBetweenDates(Date start, Date end) {
        return 0;
    }

    @Override
    public List<Route> getRoutesWithStop(Stop stop) {
        return null;
    }

    @Override
    public Long getMaxStopOfRoutes() {
        return null;
    }

    @Override
    public List<Route> getRoutsNotSell() {
        return null;
    }

    @Override
    public List<Route> getTop3RoutesWithMaxRating() {
        return null;
    }

    @Override
    public Service getMostDemandedService() {
        return null;
    }

    @Override
    public List<TourGuideUser> getTourGuidesWithRating1() {
        return null;
    }
}